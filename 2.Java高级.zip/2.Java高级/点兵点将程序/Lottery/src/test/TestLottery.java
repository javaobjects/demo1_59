package test;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * �齱���ܴ���
 * @author Mary
 *
 */
public class TestLottery extends JFrame{
	
	private JPanel panel_main;
	private JButton btn_lottery;
	private JLabel lb_display;
	private JTextArea ta;
	// ��Ż�����Ϣ�ļ���
	private static Map<Integer,String> map=null;
	
	static {
		map=new HashMap<>();
		
		try {
			//һ������£������ļ������������jar���У����Ǹ�jar�ļ�ͬһĿ¼���ã����Զ�ȡ�����ļ���Ҫ���ҵ���ǰ·��
			String rootPath = System.getProperty("user.dir").replace("\\", "/");
			
			BufferedReader reader=new BufferedReader(new FileReader(new File(rootPath+"/students.txt")));
			
			String str="";
			int i=1;
			while((str=reader.readLine())!=null)
			{
				map.put(i++, str);
			}
			System.out.println(map.size());
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void init()
	{
		panel_main=new JPanel(new GridLayout(3,1,0,30));
		btn_lottery=new JButton("��ʼ�齱");
		btn_lottery.setFont(new Font("����",Font.BOLD,30));
		lb_display=new JLabel("�齱�����ʾ��");
		lb_display.setFont(new Font("����",Font.BOLD,30));
		ta=new JTextArea(600, 60);
		ta.setFont(new Font("����",Font.BOLD,16));
		//ƴװ
		panel_main.add(btn_lottery);
		panel_main.add(lb_display);
		panel_main.add(ta);
		
		this.getContentPane().add(panel_main);
		this.setTitle("����㽫");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(700,300);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	public TestLottery()
	{
		init();
		registerActionListener();
	}
	
	private void registerActionListener()
	{
		btn_lottery.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int range=map.size();
				TreeSet<Integer> s=new TreeSet();
				//����10�������
				while(s.size()<10)
				{
					Random random=new Random();
					int number=random.nextInt(range);
					s.add(number+1);
				}
				StringBuffer sb=new StringBuffer();
				for(Integer i:s)
				{
					sb.append(map.get(i)+",");
				}
				ta.setText(sb.substring(0, sb.length()-1));
			}
		});
	}
	
	

}
